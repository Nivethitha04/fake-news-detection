<?php


use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require '../vendor/autoload.php';

require '../includes/DbOperations.php';

$app = new \Slim\App([
    'settings'=>[
        'displayErrorDetails'=>true
    ]
]);

$app->add(new Tuupola\Middleware\HttpBasicAuthentication([
    "secure"=>false,
    "users" => [
        "sathish" => "rsr",
    ]
]));

/* 
    endpoint: createuser
    parameters: email_id, password, name, school
    method: POST
*/


$app->post('/create_user', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('user_id', 'first_name', 'last_name', 'dob', 'mail_id', 'mobile_no', 'designation', 'password'), $request, $response)){

        $request_data = $request->getParsedBody(); 

        $user_id = $request_data['user_id'];
		$first_name = $request_data['first_name'];
        $last_name = $request_data['last_name'];
        $dob = $request_data['dob'];
        $mail_id = $request_data['mail_id'];
        $mobile_no = $request_data['mobile_no'];
		$designation = $request_data['designation'];
		$password = $request_data['password']; 

        // $hash_password = password_hash($password, PASSWORD_DEFAULT);

        $db = new DbOperations; 

        $result = $db->create_user($user_id, $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation, $password);
        
        if($result == USER_CREATED){

            $message = array(); 
            $message['error'] = false; 
            $message['message'] = 'User created successfully';

            $response->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(201);

        }else if($result == USER_FAILURE){

            $message = array(); 
            $message['error'] = true; 
            $message['message'] = 'Some error occurred';

            $response->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(422);    

        }else if($result == USER_EXISTS){
            $message = array(); 
            $message['error'] = true; 
            $message['message'] = 'User Already Exists';

            $response->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(422);    
        }
    }
    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);    
});



function haveEmptyParameters($required_params, $request, $response){
    $error = false; 
    $error_params = '';
    $request_params = $request->getParsedBody(); 

    foreach($required_params as $param){
        if(!isset($request_params[$param]) || strlen($request_params[$param])<=0){
            $error = true; 
            $error_params .= $param . ', ';
        }
    }

    if($error){
        $error_detail = array();
        $error_detail['error'] = true; 
        $error_detail['message'] = 'Required parameters ' . substr($error_params, 0, -2) . ' are missing or empty';
        $response->write(json_encode($error_detail));
    }
    return $error; 
}


$app->post('/user_login', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('user_id', 'password'), $request, $response)){
        $request_data = $request->getParsedBody(); 

        $user_id = $request_data['user_id'];
        $password = $request_data['password'];
        
        $db = new DbOperations; 

        $result = $db->userLogin($user_id, $password);

        if($result == USER_AUTHENTICATED){
        
            $response_data = array();

            $response_data['error']=false; 
            $response_data['message'] = 'Login Success';

            $response->write(json_encode($response_data));

            return $response
                ->withHeader('Content-type', 'application/json')
                ->withStatus(200);    

        }else if($result == USER_NOT_FOUND){
            $response_data = array();

            $response_data['error']=true; 
            $response_data['message'] = 'User does not exist';

            $response->write(json_encode($response_data));

            return $response
                ->withHeader('Content-type', 'application/json')
                ->withStatus(200);    

        }else if($result == USER_PASSWORD_DO_NOT_MATCH){
            $response_data = array();

            $response_data['error']=true; 
            $response_data['message'] = 'Invalid credential';

            $response->write(json_encode($response_data));

            return $response
                ->withHeader('Content-type', 'application/json')
                ->withStatus(200);  
        }
    }

    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);    
});


$app->post('/get_user', function(Request $request, Response $response){

    $request_data = $request->getParsedBody(); 

    $user_id = $request_data['user_id'];

    $db = new DbOperations;
    
    $users = $db->get_user($user_id);

    $response_data = array();

    $response_data['error'] = false; 
    $response_data['single_user'] = $users; 

    $response->write(json_encode($response_data));

    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);

});



$app->put('/update_user/{user_id}', function(Request $request, Response $response, array $args){

    $user_id = $args['user_id'];

    if(!haveEmptyParameters(array('first_name', 'last_name', 'dob', 'mail_id', 'mobile_no', 'designation'), $request, $response)){

        $request_data = $request->getParsedBody();
        $first_name = $request_data['first_name'];
        $last_name = $request_data['last_name'];
        $dob = $request_data['dob'];
        $mail_id = $request_data['mail_id'];
        $mobile_no = $request_data['mobile_no'];
		$designation = $request_data['designation'];

        $db = new DbOperations; 

        if($db->update_user($user_id, $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation)){
            $response_data = array(); 
            $response_data['error'] = false; 
			$response_data['message'] = 'User Updated Successfully';
			
            $response->write(json_encode($response_data));

            return $response
            ->withHeader('Content-type', 'application/json')
            ->withStatus(200);  
        
        }else{
            $response_data = array(); 
            $response_data['error'] = true; 
            $response_data['message'] = 'Please try again later';
            
            $response->write(json_encode($response_data));

            return $response
            ->withHeader('Content-type', 'application/json')
            ->withStatus(200);  
              
        }

    }
    
    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);  

});


$app->put('/reset_password', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('new_password', 'user_id'), $request, $response)){
        
        $request_data = $request->getParsedBody(); 

        $new_password = $request_data['new_password'];
        $user_id = $request_data['user_id']; 

        $db = new DbOperations; 

		if($db->isUserIDExist($user_id)==true){

        $result = $db->resetPassword($new_password, $user_id);

        if($result == PASSWORD_CHANGED){
            $response_data = array(); 
            $response_data['error'] = false;
            $response_data['message'] = 'Password Reseted';
            $response->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')
                            ->withStatus(200);

        }else{
            $response_data = array(); 
            $response_data['error'] = true;
            $response_data['message'] = 'Some error occurred';
            $response->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')
                            ->withStatus(200);
		}
	}else{
		$response_data = array(); 
		$response_data['error'] = true;
		$response_data['message'] = 'User does not exist';
		$response->write(json_encode($response_data));
		return $response->withHeader('Content-type', 'application/json')
						->withStatus(200);
	}
    }

    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);  
});


$app->get('/all_news', function(Request $request, Response $response){

    $db = new DbOperations; 

    $news = $db->get_all_news();

    $response_data = array();

    $response_data['error'] = false; 
    $response_data['news'] = $news; 

    $response->write(json_encode($response_data));

    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);  

});


$app->run();
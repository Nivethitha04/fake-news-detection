<?php 

    class DbOperations{

        private $con; 

        function __construct(){
            require_once dirname(__FILE__) . '/DbConnect.php';
            $db = new DbConnect; 
            $this->con = $db->connect(); 
        }

        public function create_user($user_id, $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation, $password){
           if(!$this->isUserIDExist($user_id)){
                $stmt = $this->con->prepare("INSERT INTO user_profile (user_id, first_name, last_name, dob, mail_id, mobile_no, designation, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssssss",$user_id, $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation, $password);
                if($stmt->execute()){
                    return USER_CREATED; 
                }else{
                    return USER_FAILURE;
                }
           }
           return USER_EXISTS; 
        }


        public function get_all_news(){
            $stmt = $this->con->prepare("SELECT url, title, time, grammar, abusive, negative, neutral, positive, distance, similar, dissimilar FROM news;");
            $stmt->execute(); 
            $stmt->bind_result($url, $title, $time, $grammar, $abusive, $negative, $neutral, $positive, $distance, $similar, $dissimilar);
            $news = array(); 
            while($stmt->fetch()){ 
                $user = array(); 
                $user['url'] = $url; 
                $user['title']=$title; 
                $user['time'] = $time; 
                $user['grammar'] = $grammar; 
                $user['abusive'] = $abusive;
                $user['negative'] = $negative;
                $user['neutral'] = $neutral;
                $user['positive'] = $positive;
                $user['distance'] = $distance;
                $user['similar'] = $similar;
                $user['dissimilar'] = $dissimilar;
                array_push($news, $user);
            }             
            return $news; 
        }

        public function get_user($user_id){
            $stmt = $this->con->prepare("SELECT user_id, first_name, last_name, dob, mail_id, mobile_no, designation FROM user_profile WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute(); 
            $stmt->bind_result($user_id, $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation);
            $users = array(); 
            while($stmt->fetch()){ 
                $user = array(); 
                $user['user_id'] = $user_id; 
                $user['first_name']=$first_name; 
                $user['last_name']=$last_name;
                $user['dob']=$dob;
                $user['mail_id'] = $mail_id; 
                $user['mobile_no'] = $mobile_no; 
                $user['designation'] = $designation;
                array_push($users, $user);
            }             
            return $users; 
        }


        public function getUserBySmartID($user_id){
            $stmt = $this->con->prepare("SELECT user_id, name, email, mobile, kulam, verify FROM temp_users WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute(); 
            $stmt->bind_result($user_id, $name, $email, $mobile, $kulam, $verify);
            $stmt->fetch(); 
            $user = array(); 
            $user['user_id'] = $user_id; 
            $user['name']=$name; 
            $user['email'] = $email; 
            $user['mobile'] = $mobile; 
            $user['kulam'] = $kulam; 
            $user['verify'] = $verify;
            return $user; 
        }

        public function update_user($user_id, $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation){
            $stmt = $this->con->prepare("UPDATE user_profile SET first_name = ?, last_name = ?, dob = ?, mail_id = ?, mobile_no = ?, designation = ? WHERE user_id = ?");
            $stmt->bind_param("sssssss", $first_name, $last_name, $dob, $mail_id, $mobile_no, $designation, $user_id);
            if($stmt->execute())
                return true; 
            return false;
        }

        public function verify_temp_user($user_id, $verify){
            $stmt = $this->con->prepare("UPDATE temp_users SET verify= ? WHERE user_id = ?");
            $stmt->bind_param("ss", $verify, $user_id);
            if($stmt->execute())
                return true; 
            return false;
        }


        public function delete_temp_user($user_id){
            $stmt = $this->con->prepare("DELETE FROM temp_users WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            if($stmt->execute())
                return true; 
            return false; 
        }

        private function isEmailExist($email){
            $stmt = $this->con->prepare("SELECT user_id FROM temp_users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute(); 
            $stmt->store_result(); 
            return $stmt->num_rows > 0;  
        }

        public function isUserIDExist($user_id){
            $stmt = $this->con->prepare("SELECT mail_id FROM user_profile WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute(); 
            $stmt->store_result(); 
            if($stmt->num_rows <= 0){
                return false;
            }
            else{
                return true;
            }
        }

        public function is_temp_user_exist($user_id){
            $stmt = $this->con->prepare("SELECT user_id FROM temp_users WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute(); 
            $stmt->store_result(); 
            if($stmt->num_rows <= 0){
                return false;
            }
            else{
                return true;
            }
        }

        public function isAdminExist($username){
            $stmt = $this->con->prepare("SELECT password FROM admin WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute(); 
            $stmt->store_result(); 
            if($stmt->num_rows <= 0){
                return false;
            }
            else{
                return true;
            }
        }

        public function userLogin($user_id, $password){
            if($this->isUserIDExist($user_id)){
                $user_password = $this->getUserPasswordByName($user_id); 
                if($password == $user_password){
                    return USER_AUTHENTICATED;
                }else{
                    return USER_PASSWORD_DO_NOT_MATCH; 
                }
            }else{
                return USER_NOT_FOUND; 
            }
        }

        public function resetPassword($new_password, $user_id){
            
            // $hash_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $this->con->prepare("UPDATE user_profile SET password = ? WHERE user_id = ?");
            $stmt->bind_param("ss",$new_password, $user_id);

            if($stmt->execute())
                return PASSWORD_CHANGED;
            else{return PASSWORD_NOT_CHANGED;}

    }

        private function getUserPasswordByName($user_id){
            $stmt = $this->con->prepare("SELECT password FROM user_profile WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute(); 
            $stmt->bind_result($password);
            $stmt->fetch(); 
            return $password; 
        }

        public function getControlByName($username){
            $stmt = $this->con->prepare("SELECT control FROM admin WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute(); 
            $stmt->bind_result($control);
            $stmt->fetch(); 
            return $control; 
        }

    }
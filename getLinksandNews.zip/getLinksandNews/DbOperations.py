import mysql.connector

conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")

myCursor = conn.cursor()

# myCursor.execute("create table links (link varchar(750) primary key);")

conn.commit()

conn.close()
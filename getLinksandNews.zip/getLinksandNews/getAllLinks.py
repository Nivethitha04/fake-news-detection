from bs4 import BeautifulSoup
from urllib.request import Request, urlopen
import re
import DbOperations
import mysql.connector
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import language_tool_python
from better_profanity import profanity
import requests
from bs4 import BeautifulSoup

import os

global blacklist, text_elements, title, posted_on

blacklist = ['video/', 'videos/', 'photo/', 'photos/', 'exam-results/', 'blog/', 'photo-gallery/', 'reviews/',
             'shows/', 'uncut/', 'topic/']

title = ""
posted_on = ""

def getArticle(s, link):

    global title, posted_on

    r = requests.get(link)
    data = r.text
    soup = BeautifulSoup(data, 'html.parser')
    blacklist = [
        'style',
        'script',
        'div',
        'span',
        'html',
        '\n',
        'title',
        'strong',
        'br'
        # other elements,
    ]
    #
    # article_data = soup.find("h1", class_="sp-ttl")
    # print(article_data.text)
    # article_data = soup.find("h2", class_="sp-descp")
    # print(article_data.text)
    # article_data = soup.find("span", class_="pst-by_lnk")
    # print(article_data.text)
    # article_data = soup.find("div", class_="sp-cn ins_storybody")
    # article_data = soup.find("div", class_="col s12 m9 l9")
    # text_elements = [t for t in soup.find_all(text=True) if t.parent.name not in blacklist]
    # for i in text_elements:
    #     print(i)

    try:
        if (s=="TheWire"):
            title = soup.find("h1", class_="title")
            title = title.text
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("span", class_="posted-on")
            posted_on = posted_on.text
            article_data = soup.find("div", class_="grey-text")
            text_elements = [t+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]

        if (s=="KeycTv"):
            title = soup.find("h1", class_="post-title")
            title = title.text
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("div", class_="post-byline")
            posted_on = str(posted_on.text)[12:]
            article_data = soup.find("div", class_="post-content")
            text_elements = [t+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]

        if (s=="abpLive"):
            title = soup.find("h1", class_="article-title")
            title = title.text
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("p", class_="article-author")
            i = str(posted_on.text).strip().index("|")+2
            posted_on = str(posted_on.text).strip()[i:]
            article_data = soup.find("div", class_="article-data _thumbBrk")
            text_elements = [t+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]

        if (s=="firstPost"):
            title = soup.find("h1", class_="inner-main-title")
            title = str(title.text).strip()
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("div", class_="author-info")
            posted_on = posted_on.find("span", class_="")
            posted_on = str(posted_on.text).strip()
            article_data = soup.find("div", class_="inner-copy article-full-content")
            text_elements = [t+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]

        if (s=="neNow"):
            title = soup.find("h1", class_="jeg_post_title")
            title = title.text
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("div", class_="jeg_meta_date")
            posted_on = str(posted_on.text).strip()
            article_data = soup.find("div", class_="content-inner")
            text_elements = [t+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]

        if (s=="newOnNews"):
            title = soup.find("h1", class_="entry-title")
            title = title.text
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("time", class_="entry-date published updated")
            posted_on = posted_on.text
            article_data = soup.find("div", class_="entry-content clearfix")
            text_elements = [t+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]

        if (s=="theNewsMill"):
            title = soup.find("span", class_="post-title")
            title = title.text
            # desc = soup.find("p", class_="shortDesc")
            # print(desc.text)
            posted_on = soup.find("time", class_="post-published updated")
            posted_on = posted_on.find("b")
            posted_on = posted_on.text
            article_data = soup.find("div", class_="entry-content clearfix single-post-content")
            text_elements = [(str(t).decode('utf-8', 'ignore').encode('ascii', 'ignore'))+'\n' for t in article_data.find_all(text=True) if t.parent.name not in blacklist]


        # text_elements = (str(text_elements).encode('ascii', 'ignore')).decode("utf-8")

        file1 = open("article.txt", "w", encoding='utf-8')
        file1.writelines(text_elements)
        file1.close()

        return True

    except:
        return False

def checkAbusive(link):
    profanity.load_censor_words()
    with open('article.txt', 'r', encoding='utf-8') as fin:
        text = fin.read()
        censored_text = profanity.censor(text)
        # print(censored_text)
        c = censored_text.count('****')
        print("Abusive: No. of abusive words found in document is ", c)

        conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")
        myCursor = conn.cursor()
        query = "update news set abusive=%s where url=%s"
        val = [c, link]
        myCursor.execute(query, val)
        conn.commit()
        conn.close()

        print()

def checkGrammar(link):
    # Mention the language keyword
    tool = language_tool_python.LanguageTool('en-US')
    i = 0

    # Path of file which needs to be checked
    with open('article.txt', 'r', encoding='utf-8') as fin:
        for line in fin:
            matches = tool.check(line)
            i = i + len(matches)
            pass

    # prints total mistakes which are found
    # from the document

    conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")
    myCursor = conn.cursor()
    query = "update news set grammar=%s where url=%s"
    val = [i, link]
    myCursor.execute(query, val)
    conn.commit()
    conn.close()


    print("Grammar: No. of mistakes found in document is ", i)

    # prints mistake one by one
    # for mistake in matches:
    #     print(mistake)
    #     print()

def putInDB(s, url):

    # myCursor.execute("create table links (url varchar(1000));")

    link = str(url)


    if(getArticle(s, link)):
        print("URL: " + link)
        print("Title:" + title)
        print("Time: " + posted_on)

        conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")
        myCursor = conn.cursor()
        query = "replace into news (url, title, time) values (%s, %s, %s)"
        val = [link, title, posted_on]
        myCursor.execute(query, val)
        conn.commit()
        conn.close()

        checkGrammar(link)
        checkAbusive(link)

        t = 'python getGoogle.py' + " " + re.sub(r'[^\w]', ' ', title)

        os.system(t)

        t = 'python contentCheck.py' + " " + link

        os.system(t)


def theNewsMill():

    s = "theNewsMill"

    ls = ["https://thenewsmill.com/", "https://thenewsmill.com/politics/", "https://thenewsmill.com/business/",
          "https://thenewsmill.com/sports/", "https://thenewsmill.com/northeast-india/arunachal-pradesh/",
          "https://thenewsmill.com/northeast-india/assam/", "https://thenewsmill.com/northeast-india/manipur/",
          "https://thenewsmill.com/northeast-india/meghalaya/", "https://thenewsmill.com/northeast-india/mizoram/",
          "https://thenewsmill.com/northeast-india/nagaland/", "https://thenewsmill.com/northeast-india/sikkim/",
          "https://thenewsmill.com/northeast-india/tripura/"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)

def newOnNews():

    s = "newOnNews"

    ls = ["https://www.newonnews.com/", "https://www.newonnews.com/category/news/india/",
          "https://www.newonnews.com/category/news/sports/", "https://www.newonnews.com/category/news/entertainment/",
          "https://www.newonnews.com/category/news/business-economy/", "https://www.newonnews.com/category/news/finance/",
          "https://www.newonnews.com/category/news/market/"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)

def neNow():

    s = "neNow"

    ls = ["https://nenow.in/", "https://nenow.in/category/business", "https://nenow.in/category/entertainment",
          "https://nenow.in/category/sports", "https://nenow.in/category/environment", "https://nenow.in/category/citizen-journalists",
          "https://nenow.in/category/north-east-news/assam", "https://nenow.in/category/north-east-news/meghalaya",
          "https://nenow.in/category/north-east-news/tripura", "https://nenow.in/category/north-east-news/mizoram",
          "https://nenow.in/category/north-east-news/manipur", "https://nenow.in/category/north-east-news/nagaland",
          "https://nenow.in/category/north-east-news/arunachal-pradesh", "https://nenow.in/category/north-east-news/sikkim"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)

def firstPost():

    s = "firstPost"

    ls = ["https://www.firstpost.com/", "https://www.firstpost.com/category/health", "https://www.firstpost.com/category/india",
          "https://www.firstpost.com/category/world", "https://www.firstpost.com/category/politics",
          "https://www.firstpost.com/category/art-and-culture", "https://www.firstpost.com/category/business",
          "https://www.firstpost.com/category/sports", "https://www.firstpost.com/category/entertainment"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)

def abpLive():

    s = "abpLive"

    ls = ["https://news.abplive.com/", "https://news.abplive.com/latest-news", "https://news.abplive.com/latest-news/page-2",
          "https://news.abplive.com/news/india", "https://news.abplive.com/news/world", "https://news.abplive.com/entertainment",
          "https://news.abplive.com/education", "https://news.abplive.com/sports", "https://news.abplive.com/business",
          "https://news.abplive.com/auto", "https://news.abplive.com/health", "https://news.abplive.com/lifestyle",
          "https://news.abplive.com/personal-finance"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)

def KeycTv():

    s = "KeycTv"

    ls = ["https://www.keyc.tv/page/1", "https://www.keyc.tv/page/2", "https://www.keyc.tv/page/3"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)

def TheWire():

    s = "TheWire"

    ls = ["https://thewire.in/category/politics/all", "https://thewire.in/category/economy/all",
          "https://thewire.in/category/external-affairs/all", "https://thewire.in/category/security/all",
          "https://thewire.in/category/law/all", "https://thewire.in/category/science/all",
          "https://thewire.in/category/society/all", "https://thewire.in/category/culture/all",
          "https://thewire.in/opinion/all", "https://thewire.in"]
    for i in ls:
        req = Request(i, headers={'User-Agent': 'Mozilla/5.0'})
        html_page = urlopen(req)

        soup = BeautifulSoup(html_page, "lxml")

        links = []
        for link in soup.findAll('a'):
            links.append(link.get('href'))

        links = list(set(links))

        for l in links:
            if (str(l).startswith('http') or str(l).startswith('https')) and (str(l).count('-')>=7
                                                                              and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, l)
            elif (str(l).count('-')>=7 and not any(x in l for x in blacklist)):
                # print(l)
                putInDB(s, "https://thewire.in"+l)

#start getting links
TheWire()
KeycTv()
abpLive()
firstPost()
neNow()
newOnNews()
theNewsMill()
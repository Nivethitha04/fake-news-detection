#import SentimentIntensityAnalyzer class
#from vaderSentiment.vaderSentiment module.
import mysql.connector
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


global link

link = ""

# function to print sentiments
# of the sentence.
def sentiment_scores(sentence):
    # Create a SentimentIntensityAnalyzer object.
    sid_obj = SentimentIntensityAnalyzer()

    # polarity_scores method of SentimentIntensityAnalyzer
    # oject gives a sentiment dictionary.
    # which contains pos, neg, neu, and compound scores.
    sentiment_dict = sid_obj.polarity_scores(sentence)

    print("Overall sentiment dictionary is : ", sentiment_dict)
    a=sentiment_dict['neg'] * 100
    b=sentiment_dict['neu'] * 100
    c=sentiment_dict['pos'] * 100

    a = round(a, 2)
    b = round(b, 2)
    c = round(c, 2)


    print(a, "% Negative")
    print(b, "% Neutral")
    print(c, "% Positive")

    conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")
    myCursor = conn.cursor()
    query = "update news set negative=%s, neutral=%s, positive=%s where url=%s"
    val = [a, b, c, link]
    myCursor.execute(query, val)
    conn.commit()
    conn.close()

    return a,b,c

# Driver code
if __name__ == "__main__":
    import sys

    argumentList = sys.argv

    link = argumentList[1]

    with open(r'article.txt','r', encoding='utf-8') as f:
           x,y,z= sentiment_scores(f)
import math
import string
import sys

# reading the text file
# This functio will return a
# list of the lines of text
# in the file.
def read_file(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = f.read()
        return data

    except IOError:
        print("Error opening or reading input file: ", filename)
        sys.exit()

    # splitting the text lines into words


# translation table is a global variable
# mapping upper case to lower case and
# punctuation to spaces
translation_table = str.maketrans(string.punctuation + string.ascii_uppercase,
                                  " " * len(string.punctuation) + string.ascii_lowercase)


# returns a list of the words
# in the file
def get_words_from_line_list(text):
    text = text.translate(translation_table)
    word_list = text.split()

    return word_list


# counts frequency of each word
# returns a dictionary which maps
# the words to their frequency.
def count_frequency(word_list):
    D = {}

    for new_word in word_list:

        if new_word in D:
            D[new_word] = D[new_word] + 1

        else:
            D[new_word] = 1

    return D


# returns dictionary of (word, frequency)
# pairs from the previous dictionary.
def word_frequencies_for_file(filename):
    line_list = read_file(filename)
    word_list = get_words_from_line_list(line_list)
    freq_mapping = count_frequency(word_list)

    #print("File", filename, ":", )
    #print(len(line_list), "lines, ", )
    #print(len(word_list), "words, ", )
    #print(len(freq_mapping), "distinct words")

    return freq_mapping


# returns the dot product of two documents
def dotProduct(D1, D2):
    Sum = 0.0

    for key in D1:

        if key in D2:
            Sum += (D1[key] * D2[key])

    return Sum


# returns the angle in radians
# between document vectors
def vector_angle(D1, D2):
    numerator = dotProduct(D1, D2)
    denominator = math.sqrt(dotProduct(D1, D1) * dotProduct(D2, D2))

    try:
        return math.acos(numerator / denominator)
    except Exception as e:
        denominator = math.sqrt(dotProduct(D1, 2) * dotProduct(D2, 2))
        return math.acos(numerator / denominator)


def documentSimilarity(filename_1, filename_2):
    # filename_1 = sys.argv[1]
    # filename_2 = sys.argv[2]
    sorted_word_list_1 = word_frequencies_for_file(filename_1)
    sorted_word_list_2 = word_frequencies_for_file(filename_2)
    distance = vector_angle(sorted_word_list_1, sorted_word_list_2)

    print("The distance between the documents is: % 0.6f (radians)" % distance)

    conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")
    myCursor = conn.cursor()
    query = "update news set distance=%s where url=%s"
    val = [round(distance, 3), link]
    myCursor.execute(query, val)
    conn.commit()
    conn.close()

    return distance

# Driver code
distance=documentSimilarity('test.txt', 'article.txt')

similar = 0
dissimilar = 0

if(x>z):
    rate1 = ((distance - 0) * 100) / (0.3 - 0);
    if(rate1==0):
        similar = 100
        print("similar-100%")
    elif (rate1 >= 100):
        dissimilar = 100
        print("dissimilar-100%")
    elif(0<rate1<100):
        similar = rate1
        dissimilar = 100-rate1
        print("similar-{:.2f}%".format(rate1), "\ndissimilar-{:.2f}%".format(100-rate1))
elif(y>z):
    rate3 = ((distance - 0) * 100) / (1.5- 0);
    if(rate3>=100):
        dissimilar = 100
        print("dissimilar-100%")
    if (rate3== 0):
        similar = 100
        print("similar-100%")
    elif(0<rate3<100):
        if(rate3<50):
            similar = 100 - rate3
            dissimilar = rate3
            print("similar-{:.2f}%".format(100-rate3), "\ndissimilar-{:.2f}%".format(rate3))
        else:
            similar = rate3
            dissimilar = 100 - rate3
            print("similar-{:.2f}%".format(rate3), "\ndissimilar-{:.2f}%".format(100-rate3))


else:
    rate2 = ((distance - 0) * 100) / (0.7 - 0)
    if ((distance < 0.7) and (rate2 == 0)):
        similar = 100
        print("similar-100%")
    if(rate2 >= 100):
        dissimilar = 100
        print("dissimilar-100%")
    elif(0<rate2<100):
        similar = 100 - rate2
        dissimilar = rate2
        print("similar-{:.2f}%".format(100-rate2), "\ndissimilar-{:.2f}%".format(rate2))

conn = mysql.connector.connect(host="localhost", user="root", passwd="", db="frank.ly")
myCursor = conn.cursor()
query = "update news set similar=%s, dissimilar=%s where url=%s"
val = [round(similar, 2), round(dissimilar, 2), link]
myCursor.execute(query, val)
conn.commit()
conn.close()